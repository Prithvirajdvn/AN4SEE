# Sign_Language > 2024-10-31 9:51am
https://universe.roboflow.com/dvn-prithvi-raj/sign_language-mrdoz

Provided by a Roboflow user
License: CC BY 4.0

